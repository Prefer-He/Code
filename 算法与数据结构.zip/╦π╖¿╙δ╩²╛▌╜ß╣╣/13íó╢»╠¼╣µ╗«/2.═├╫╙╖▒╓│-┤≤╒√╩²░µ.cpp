/*************************************************************************
	> File Name: 2.兔子繁殖-大整数版.cpp
	> Author:hepeiyang 
	> Mail:2794273689@qq.com
	> Created Time: Sun 08 Oct 2023 07:09:48 PM CST
 ************************************************************************/

#include<iostream>
using namespace std;

int main(){



    return 0;
}
