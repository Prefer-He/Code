/*************************************************************************
	> File Name: 13.括号画家-HZOJ-265.cpp
	> Author:hepeiyang 
	> Mail:2794273689@qq.com
	> Created Time: Sun 15 Oct 2023 03:26:56 PM CST
 ************************************************************************/

#include<iostream>
using namespace std;


int main(){



    return 0;
}
