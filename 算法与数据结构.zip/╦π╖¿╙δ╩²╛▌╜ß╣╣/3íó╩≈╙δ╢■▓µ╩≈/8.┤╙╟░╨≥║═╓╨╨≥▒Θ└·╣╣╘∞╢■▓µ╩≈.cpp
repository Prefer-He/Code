/*************************************************************************
	> File Name: 8.从前序和中序遍历构造二叉树.cpp
	> Author:hepeiyang 
	> Mail:2794273689@qq.com
	> Created Time: Sun 15 Oct 2023 04:08:52 PM CST
 ************************************************************************/

#include<iostream>
using namespace std;


int main(){



    return 0;
}
